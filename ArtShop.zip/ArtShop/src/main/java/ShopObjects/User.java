package ShopObjects;
import java.util.Scanner;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
public class User {
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //variables
    private String userId;
    private String name;
    private String password;
    private String email;
    private String phoneNum;
    private String address;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //constructors
    public User() {
    }

    public User(String userId, String name, String password,  String email, String phoneNum, String address) {
        this.userId = userId;
        this.password = password;
        this.name = name;
        this.email = email;
        this.phoneNum = phoneNum;
        this.address = address;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //setters and getters    
    public String getUserId() {
            return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String passWord) {
        this.password = passWord;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhoneNum() {
        return phoneNum;
    }

    public void setPhoneNum(String phoneNum) {
        this.phoneNum = phoneNum;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }  
//------------------------------------------------------------------------------//------------------------------------------------------------------------------        
    // method to validate phone number
    public static boolean isValidPhoneNumber(String phoneNumber) {
        return phoneNumber.matches("05\\d{8}");
    }
//------------------------------------------------------------------------------//------------------------------------------------------------------------------    
     // method to validate password   
     public static boolean isValidPassword(String s) {
        boolean onlyLettersAndDigits = true;
        int letterCount = 0;
        int digitCount = 0;
    
        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
    
            if (!(Character.isLetter(ch) || Character.isDigit(ch))) {
                onlyLettersAndDigits = false;
                break;
            }
    
            if (Character.isLetter(ch)) {
                letterCount++;
            } else if (Character.isDigit(ch)) {
                digitCount++;
            }
        }
    
        return onlyLettersAndDigits && (s.length() >= 5) && (letterCount >= 2) && (digitCount >= 3);
    }
//------------------------------------------------------------------------------//------------------------------------------------------------------------------    
    // method to validate name    
    public static boolean containsOnlyLetters(String s) {
    for (int i = 0; i < s.length(); i++) {
        if (!Character.isLetter(s.charAt(i))) {
            return false;
        }
    }
    return true;
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------    
    // method to validate email  
    public static boolean isValidEmailDomain(String email) {
        
        // Define the valid email domains
        String[] validDomains = {"gmail.com", "outlook.com", "hotmail.com", "icloud.com", "yahoo.com"};

        // Check if the email address ends with any of the valid domains
        for (String domain : validDomains) {
            if (email.toLowerCase().endsWith("@" + domain)) {
                return true;
            }
        }

        return false;
    }
    //------------------------------------------------------------------------------//------------------------------------------------------------------------------
    public static boolean isValidCity(String city) {
        // List of valid cities
        String[] validCities = {"Riyadh", "Jeddah", "Dhahran", "Dammam", "Khobar"};

        // Check if the entered city is in the list of valid cities
        for (String validCity : validCities) {
            if (validCity.equalsIgnoreCase(city.trim())) {
                return true;
            }
        }
        return false;
    }
//------------------------------------------------------------------------------//------------------------------------------------------------------------------   
    // method for updating user info
    public void updateInformationMenu(Scanner input) {
        int infoChoice;
        boolean exitMenu = false;

        while (!exitMenu) {
            System.out.println("Do you want to update your\n1. Name\n2. Password\n3. Email\n4. Phone Number\n5. Address\n0. Nothing (Close the menu)");
            infoChoice = input.nextInt();
            input.nextLine();

            switch (infoChoice) {
                case 1:
                    String newName;
                    System.out.println("Enter the new name: ");
                    do {
                        newName = input.nextLine();
                        if (!User.containsOnlyLetters(newName)) {
                            System.out.println("Invalid name");
                        }
                    } while (!User.containsOnlyLetters(newName));
                    // Update the name 
                    this.setName(newName);
                    System.out.println("Name Changed Successfully!");
                    break;
                case 2:
                    String oldPassword, newPassword;
                    System.out.println("Enter the old password: ");
                    oldPassword = input.nextLine();
                    if (oldPassword.equals(this.getPassword())) {
                        do {
                            System.out.println("Enter the new password");
                            newPassword = input.nextLine();
                            if (!User.isValidPassword(newPassword)) {
                                System.out.println("Invalid password");
                            }
                        } while (!User.isValidPassword(newPassword));
                        // Update the password
                        this.setPassword(newPassword);
                        System.out.println("Password Changed Successfully!");
                    } else {
                        System.out.println("Incorrect old password. Password not changed.");
                    }
                    break;
                case 3:
                    String newEmail;
                    System.out.println("Enter the new email: ");
                    do {
                        newEmail = input.nextLine();
                        if (!User.isValidEmailDomain(newEmail)) {
                            System.out.println("Invalid Email");
                        }
                    } while (!User.isValidEmailDomain(newEmail));
                    // Update the email 
                    this.setEmail(newEmail);
                    System.out.println("Email Changed Successfully!");
                    break;
                case 4:
                    String newPhoneNum;
                    System.out.println("Enter the new phone number: ");
                    do {
                        newPhoneNum = input.nextLine();
                        if (!User.isValidPhoneNumber(newPhoneNum)) {
                            System.out.println("Invalid phone number");
                        }
                    } while (!User.isValidPhoneNumber(newPhoneNum));
                    // Update the phone number
                    this.setPhoneNum(newPhoneNum);
                    System.out.println("Phone Number Changed Successfully!");
                    break;
                case 5:
                    String newAddress;
                    System.out.println("Enter the new address");
                    do {
                    newAddress = input.nextLine();
                    if (!isValidCity(newAddress)) {
                        System.out.println("Invalid address. Please enter a valid city from the list: Riyadh, Jeddah, Dhahran, Dammam, Khobar");
                    }
                    } while (!isValidCity(address));
                    // Update the address
                    this.setAddress(newAddress);
                    System.out.println("Address Changed Successfully!");
                    break;
                case 0:
                    exitMenu = true;
                    break;
                default:
                    System.out.println("Invalid Entry");
                    break;
            }
        }
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
} //end of User class.

  