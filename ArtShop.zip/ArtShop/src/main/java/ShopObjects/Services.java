package ShopObjects;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
public class Services {
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //variables
    public String serviceId;
    private String name;
    private double price;
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //constructors
    public Services(){  
        this.serviceId = "";
        this.name = "";
        this.price = 0.0;
    }
    
    public Services(String serviceId, String name, double price){ 
        
        this.serviceId=serviceId;
        this.name=name;
        this.price=price;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //setters and getters
    public double getPrice(){
        return this.price;
    }
    
    public String getName(){
        return this.name;
    }
    
    public void setPrice(double price){
        this.price=price;
        
    }
    public void setName(String name){
        this.name=name;
        
    }

//---------------------------------------------------------------------------------------------------------------------------------------------------------       
} // end of Services class.