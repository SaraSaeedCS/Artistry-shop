package ShopObjects;

import java.util.*;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
public class Supplies extends Services {
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //variables
    private String brand;
    private String typeOfMedium;
    private String professionalOrBeginner;
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //constructors
    public Supplies(){
        super( );     
        
    }
    
    public Supplies(String serviceId, String name , double price, String brand, String typeOfMedium, String professionalOrBeginner){       
        super(serviceId, name, price );
        this.brand = brand;
        this.typeOfMedium = typeOfMedium;
        this.professionalOrBeginner = professionalOrBeginner;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //setters and getters 
    public String getBrand(){
        return this.brand;
        
    }

    @Override
    public String getName() {
        return super.getName(); 
    }
    
    
    public String getTypeOfMedium(){
        return this.typeOfMedium;
        
    }
    
    public void setBrand(String brand){
        this.brand=brand;
    }
    
    public void setTypeOfMedium(String typeOfMedium){
        this.typeOfMedium=typeOfMedium;
        
    }
    
    public String getProfessionalOrBeginner(){
        return this.professionalOrBeginner;
    }
    
    public void setProfessionalOrBeginner(String professionalOrBeginner){
       this.professionalOrBeginner = professionalOrBeginner;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    // Method to print the supplies menu
    public static void suppliesMenu(ArrayList<Supplies> supplies) {
        System.out.println("-- Supplies Menu --");
        System.out.printf("%-15s%-25s%-15s%-20s%-20s%-25s%n",
                "Service Id", "Name", "Price (SR)", "Brand", "Type Of Medium", "Professional or Beginner");
        System.out.println("-----------------------------------------------------------------------------------------------------------------");

        for (Supplies s : supplies) {
            System.out.printf("%-15s%-25s%-15s%-20s%-20s%-25s%n",
                    s.serviceId, s.getName(), s.getPrice() + " SR",
                    s.getBrand(), s.getTypeOfMedium(), s.getProfessionalOrBeginner());
        }
        System.out.println("-----------------------------------------------------------------------------------------------------------------");
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    // Method to check if the entered supply ID is valid
    public static boolean isValidSupplyId(String supplyId, ArrayList<Supplies> supplies) {
        for (Supplies supply : supplies) {
            if (supply.serviceId.equals(supplyId)) {
                return true;
            }
        }
        return false;
    }  
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
} // end of Supplies class.
