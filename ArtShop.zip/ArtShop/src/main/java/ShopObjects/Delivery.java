package ShopObjects;

//---------------------------------------------------------------------------------------------------------------------------------------------------------
class Delivery{
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //variables
    private String deliveryAddress;
    private String deliveryDate;
    public String deliveryPreference;
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //constructors
    public Delivery() {
    }
    
    Delivery(String deliveryAddress,String deliveryDate, String deliveryPreference){
        this.deliveryAddress = deliveryAddress;
        this.deliveryDate = deliveryDate;
        this.deliveryPreference = deliveryPreference;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //setters and getters
    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public String getDeliveryAddress() {
        return deliveryAddress;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------     
} // end of Delivery class
