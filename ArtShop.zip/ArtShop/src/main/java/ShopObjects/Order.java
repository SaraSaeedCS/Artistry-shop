package ShopObjects;


import java.util.ArrayList;
import java.util.*;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
public class Order {
    Scanner input = new Scanner(System.in);
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //variables
    private String orderId;
    private int numOfItems;
    private ArrayList<Services> items;
    public Payment payment;
    private Cart cart;
    public Delivery delivery;
    private Date date;
    private int orderRating;
    private static double averageRating;

    
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //constructors
    public Order() {
        this.orderId = "" + (int) (10000 + (Math.random() * (99999 - 1000 + 1)));
        this.cart = new Cart();
        this.items = new ArrayList<>();
        this.payment = new Payment();
        this.delivery = new Delivery();
        this.date = new Date();
    }

    public Order(String orderId, int numOfItems, ArrayList<Services> items,
                 Payment payment, Delivery delivery, Date date, int orderRating) {
        this.orderId = orderId;
        this.numOfItems = numOfItems;
        this.items = new ArrayList<>(items);
        this.payment = payment;
        this.delivery = delivery;
        this.date = date;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    // setters and getters
    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }
     
    public int getNumOfItems() {
        return numOfItems;
    }

    public void setNumOfItems(int numOfItems) {
        this.numOfItems = numOfItems;
    }

    public ArrayList<Services> getItems() {
        return new ArrayList<>(items);
    }

    public void setItems(ArrayList<Services> items) {
        this.items = new ArrayList<>(items);
    }

    public Payment getPayment() {
        return payment;
    }
    
    public void setPayment(Payment payment) {
        this.payment = payment;
    }

    public Cart getCart() {
        return cart;
    }

    public void setCart(Cart cart) {
        this.cart = cart;
    }

    public Delivery getDelivery() {
        return delivery;
    }

    public void setDelivery(Delivery delivery) {
        this.delivery = delivery;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }
    
        public int getOrderRating() {
        return orderRating;
    }


    public void setOrderRating(int orderRating) {
        this.orderRating = orderRating;
    }
    
    public static double getAverageRating() {
        return averageRating;
    }

    public void setAverageRating(double averageRating) {
        this.averageRating = averageRating;
    }
    
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    public static double calculateAverageRating(ArrayList<Order> orders) {
    int totalRatings = 0;

    if (orders.isEmpty()) {
        averageRating = 0.0;
    } else {
        for (Order order : orders) {
            totalRatings += order.getOrderRating();
        }
        // Calculate average using double to get decimal values
        averageRating = (double) totalRatings / orders.size();
    }
    return averageRating;
}
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
public int collectCustomerRating() {
    do {
        System.out.println("Rate your experience out of 5 (0-5): ");
        while (!input.hasNextInt()) {
            System.out.println("Please enter a valid integer.");
            input.next();
        }
        int rating = input.nextInt();
        
        // Set the orderRating for the current order instance
        this.orderRating = rating;

    } while (orderRating < 0 || orderRating > 5);

    return orderRating;
}
//---------------------------------------------------------------------------------------------------------------------------------------------------------   
    public String amount(Customer customer) {

    // Check if the customer has a membership
    if (customer.getMembership().equals("Yes")) {
        
        if (cart.getTotal() >= 500) {
            return "Total Amount Paid After Discount: " + cart.getTotal() + "SR";
            
        } else {
            
            return "Total Amount Paid (No Discount): " + cart.getTotal()+ "SR";
        }
    } else if (customer.getMembership().equals("No")){
        if (cart.getTotal() >= 500) {
            return "Total Amount Paid After Discount: " + cart.getTotal() + "SR";
            
        } else {
            
            return "Total Amount Paid (No Discount): " + cart.getTotal()+ "SR";
        }
    }
    else return "can't process";
        
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //method that prints the receipt after ordering
    public void getReceipt(Customer customer) {
        System.out.println("----------------------------------------------------------------------");
        System.out.println("Customer ID: "+ customer.getUserId());
        System.out.println("Customer Name: " + customer.getName());
        System.out.println("Customer phone number: "+ customer.getPhoneNum());
        System.out.println("Order ID: " + orderId);
        System.out.println("Number of Items: " + cart.getNumOfItems());
        System.out.println("Items ordered: " + cart.getItems());
        System.out.println(amount(customer));
        System.out.println("Expected Delivery Date: " + delivery.getDeliveryDate());
        System.out.println("Delivery to: " + delivery.getDeliveryAddress());
        System.out.println("Ordered On: " + date);
        System.out.println("Payment Method Used: " + payment.getPaymentMethod());
        System.out.println("Thank you for your purchase!");
        Payment payment = getPayment();

        if (payment instanceof ApplePay) {
            ApplePay applePay = (ApplePay) payment;
            applePay.sendApplePayConfirmationMessage(customer.getPhoneNum(), amount(customer), applePay.getApplePayToken());
        } else if (payment instanceof CreditCard) {
            CreditCard creditCard = (CreditCard) payment;
            creditCard.sendCreditCardConfirmationEmail(customer.getEmail(), amount(customer), creditCard.getTransactionId());
        }    
    }
 //---------------------------------------------------------------------------------------------------------------------------------------------------------   
} // end of Order class
