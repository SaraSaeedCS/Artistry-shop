package ShopObjects;
import ShopObjects.Services;
import ShopObjects.Supplies;
import java.util.*;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
public class Cart {
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //variables
    private int numOfItems;
    private double total;
    private ArrayList<Services> items;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //constructors
    public Cart() {
        this.numOfItems = 0;
        this.total = 0.0;
        this.items = new ArrayList<>();
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //setters and getters
    public int getNumOfItems() {
        return numOfItems;
    }

    public double getTotal() {
        return total;
    }
    
    public void setTotal(double total) {
        this.total = total;
    }

    public List<Services> getItems() {
        return items;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    // method to add an item to cart
    public void addItem(String itemId, ArrayList<? extends Services> services) {
        for(Services s:services ) {
            if (s.serviceId.equals(itemId))
                items.add(s);}
            updateCart(itemId, services);
            //System.out.println("Item added to the cart.");
        } 
        //else {
            //System.out.println("Item not found. Please enter a valid item ID.");
        //}
    
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //method to check if the item exists
    private boolean itemExists(String itemId, ArrayList<? extends Services> services) {
        for (Services service : services) {
            if (service.serviceId.equals(itemId)) {
                return true;
            }
        }
        return false;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //method to update the cart info after adding something
    private void updateCart(String itemId, ArrayList<? extends Services> services) {
        for (Services service : services) {
            if (service.serviceId.equals(itemId)) {
                numOfItems++;
                total += service.getPrice();
                break;
            }
        }
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //method to remove an item from the cart
    public void removeItem(String itemId, ArrayList<? extends Services> services) {
        if (itemExists(itemId, services)) {
            for (Services service : services) {
                if (service.serviceId.equals(itemId)) {
                    items.remove(service);
                    numOfItems--;
                    total -= service.getPrice();
                    break;
                }
            }
           
        } 
        else {
            System.out.println("Item not found in the cart. Please enter a valid item ID.");
        }
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //method to clear the cart
    public void clearCart() {
        numOfItems = 0;
        total = 0.0;
        items.clear();
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    public void addEventToCart(Scanner input, ArrayList<Event> events) {
    Event.eventMenu(events);
    System.out.println("Enter the service ID of the item you want to add (enter '0' to cancel): ");

    // Validate input for event ID
    String eventId;
    while (true) {
        eventId = input.next();
        if (eventId.equals("0")) {
            System.out.println("Adding event to the cart canceled.");
            return;  // exit the method if the user enters '0'
        } else if (Event.isValidEventId(eventId, events)) {
            addItem(eventId, events);
            return;  // exit the method if the item is added
        } else {
            System.out.println("Invalid service ID. Please enter a valid ID or enter '0' to cancel.");
        }
    }
}
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    public void addPaintingToCart(Scanner input, ArrayList<Paintings> paintings) {
    Paintings.paintingsMenu(paintings);
    System.out.println("Enter the service ID of the item you want to add (enter '0' to cancel): ");

    // Validate input for painting ID
    String paintingId;
    while (true) {
        paintingId = input.next();
        if (paintingId.equals("0")) {
            System.out.println("Adding painting to the cart canceled.");
            return;  // exit the method if the user enters '0'
        } else if (Paintings.isValidPaintingId(paintingId, paintings)) {
            addItem(paintingId, paintings);
            return;  // exit the method if the item is added
        } else {
            System.out.println("Invalid service ID. Please enter a valid ID or enter '0' to cancel.");
        }
    }
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------
public void addSuppliesToCart(Scanner input, ArrayList<Supplies> supplies) {
    Supplies.suppliesMenu(supplies);
    System.out.println("Enter the service ID of the item you want to add (enter '0' to cancel): ");

    // Validate input for supply ID
    String supplyId;
    while (true) {
        supplyId = input.next();
        if (supplyId.equals("0")) {
            System.out.println("Adding supply to the cart canceled.");
            return;  // exit the method if the user enters '0'
        } else if (Supplies.isValidSupplyId(supplyId, supplies)) {
            addItem(supplyId, supplies);
            return;  // exit the method if the item is added
        } else {
            System.out.println("Invalid service ID. Please enter a valid ID or enter '0' to cancel.");
        }
    }
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------    
} //end of Cart class

