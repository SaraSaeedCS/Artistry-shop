package ShopObjects;
import java.util.*;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
public class Event extends Services {
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //variables
    private String free;
    private String online;
    private Calendar date;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //Constructors
    public Event(){
            super();
            this.free = "";
            this.online = "";
            this.date = Calendar.getInstance();
     }
    
    public Event(String serviceId, String name,  double price, String free,
            String online, int dateYr, int dateMonth, int dateDay ) 
    {
        super(serviceId, name, price);
        this.free = free;
        this.online = online;
        //needs 
        this.date= Calendar.getInstance();
        this.date.set(Calendar.YEAR, dateYr);
        this.date.set(Calendar.MONTH,dateMonth);
        this.date.set(Calendar.DATE,dateDay);
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    // setters and getters
    public String getFree()
    {
        return free;
    }
    public void setFree( String free )
    {
        this.free = free;
    }
    public String getOnline()
    {
        return online;
    }
    public void setOnline( String online )
    {
        this.online = online;
    }   
    public Date getDate()
    {
        return date.getTime();
    }
    public void setDate( int year, int month, int day )
    {
        this.date.set(Calendar.YEAR, year);
        this.date.set(Calendar.MONTH,month);
        this.date.set(Calendar.DATE,day);
    }  
//---------------------------------------------------------------------------------------------------------------------------------------------------------   
    // Method to print the events menu
    public static void eventMenu(ArrayList<Event> events) {
        System.out.println("-- Events Menu --");
        System.out.printf("%-15s%-25s%-15s%-10s%-15s%-25s%n",
                "Service Id", "Name", "Price (SR)", "Free", "Online", "Date");
        System.out.println("-----------------------------------------------------------------------------------------------------------------");

        for (Event ev : events) {
            System.out.printf("%-15s%-25s%-15s%-10s%-15s%-25s%n",
                    ev.serviceId, ev.getName(), ev.getPrice() + " SR",
                    ev.getFree(), ev.getOnline(), ev.getDate());
        }
        System.out.println("-----------------------------------------------------------------------------------------------------------------");
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------   
// Method to check if the entered event ID is valid
    public static boolean isValidEventId(String eventId, ArrayList<Event> events) {
        for (Event event : events) {
            if (event.serviceId.equals(eventId)) {
                return true;
            }
        }
        return false;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
} // end of Event class
