package ShopObjects;
//---------------------------------------------------------------------------------------------------------------------------------------------------------

import ShopObjects.Cart;

public class Payment {
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //variables
    public String paymentMethod;
    public static final double DISCOUNT = 0.15;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //constructors
    Payment() {
        this.paymentMethod = "";
    }

    Payment(String paymentMethod) {
        this.paymentMethod = paymentMethod;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //setters and getters
     public String getPaymentMethod() {
        return this.paymentMethod;
    }
    
    public void setPaymentMethod(String paymentMethod){
        this.paymentMethod = paymentMethod;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //method no disount
    void calTotal(Cart cart) {
        double total = cart.getTotal();
        double updatedTotal = total;

        // Set the updated total back to the order
        cart.setTotal(updatedTotal);
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //method to calculate the total amount after discount
    double discount(Cart cart) {
        if (cart.getTotal() >= 500) {
            calTotal(cart, DISCOUNT);
        } else {
            calTotal(cart);
        }
        return cart.getTotal();
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //method discount 
    void calTotal(Cart cart, double DISCOUNT) {
        double total = cart.getTotal();

        // Apply the discount
        double discountedTotal = total - (total * DISCOUNT);

        // Set the updated total back to the order
        cart.setTotal(discountedTotal);
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------   
} // end of Payment class