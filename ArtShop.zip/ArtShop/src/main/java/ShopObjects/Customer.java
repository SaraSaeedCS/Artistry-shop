package ShopObjects;

import java.util.*;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
class Customer extends User {
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    public static int numOfCustomers;
    private String membership;
    
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    
    Customer (String userId, String name,String password,String email, String phoneNum, String address, String membership){
    super(userId, name, password, email, phoneNum, address);
    this.membership = membership;
    
    numOfCustomers++;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    // setter and getters
    public String getMembership(){
    return membership;
    }

    public void setMembership(String m){
    this.membership=m;
    } 
    
    
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //method for signing up a new customer
    public static Customer signUp(Scanner input, ArrayList<Customer> customers) {
        String name;
        String email;
        String phoneNum;
        String address;
        String password;
        String membership;
        String userId;

        // Validate if the name contains only letters
        System.out.println("Please enter your name: ");
        do {
            name = input.nextLine();
            if (!User.containsOnlyLetters(name)) {
                System.out.println("Invalid name");
            }
        } while (!User.containsOnlyLetters(name));

        // Validate input for email
        System.out.println("Please enter your email address: ");
        do {
            email = input.nextLine();
            if (!User.isValidEmailDomain(email)) {
                System.out.println("Invalid email address");
            }
        } while (!User.isValidEmailDomain(email));

        // Validate input for phone number
        System.out.println("Please enter your phone number: ");
        do {
            phoneNum = input.nextLine();
            if (!User.isValidPhoneNumber(phoneNum)) {
                System.out.println("Invalid phone number");
            }
        } while (!User.isValidPhoneNumber(phoneNum));

        // Entering the address
        System.out.println("Please enter your Address: ");
        do {
            address = input.nextLine();
            if (!isValidCity(address)) {
                System.out.println("Invalid address. Please enter a valid city from the list: Riyadh, Jeddah, Dhahran, Dammam, Khobar");
            }
        } while (!isValidCity(address));
        
        // Validate input for password
        System.out.println("Please choose a password: \n(at least 5 characters containing 2 letters and 3 digits)");
        do {
            password = input.nextLine();
            if (!User.isValidPassword(password)) {
                System.out.println("Invalid Password");
            }
        } while (!User.isValidPassword(password));

        // Ask if the user wants to sign up for the membership
        System.out.println("Would you like to sign up for a membership?\nEnter 1 for yes or 0 for no: ");

        // Validate input for membership choice
        int yesOrNo;
        while (true) {
            if (input.hasNextInt()) {
                yesOrNo = input.nextInt();
                if (yesOrNo == 0 || yesOrNo == 1) {
                    break;
                } else {
                    System.out.println("Invalid choice. Please enter 1 or 0.");
                    input.nextLine(); // consume the invalid input
                }
            } else {
                System.out.println("Invalid input. Please enter a number.");
                input.next(); // consume the invalid input
            }
        }

        membership = (yesOrNo == 1) ? "Yes" : "No";
        userId = "" + (int) (1000 + (Math.random() * (9999 - 1000 + 1)));

        Customer customer = new Customer(userId, name, password, email, phoneNum, address, membership);
        System.out.println("Sign-up successful!\nYour userId is: " + customer.getUserId());
        customers.add(customer);

        return customer;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //method to login existing customer
    public static Customer login(Scanner input, ArrayList<Customer> customers) {
        System.out.println("Enter userId: ");
        String enteredUserId = input.nextLine();
        System.out.println("Enter your password: ");
        String enteredPassword = input.nextLine();

        // Check if the entered userId exists in the Customer ArrayList
        Customer loggedInCustomer = null;
        for (Customer c : customers) {
            if (c.getUserId().equals(enteredUserId)) {
                loggedInCustomer = c;
                break;
            }
        }

        if (loggedInCustomer != null) {
            // Check if the entered password matches the stored password
            if (enteredPassword.equals(loggedInCustomer.getPassword())) {
                System.out.println("Login successful! Welcome, " + loggedInCustomer.getName());
                return loggedInCustomer;
            } else {
                System.out.println("Incorrect password. Please try again.");
            }
        } else {
            System.out.println("Customer ID not found. Please check your credentials or sign up.");
        }

        return null;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
} // end of Customer class

