package ShopObjects;

import java.util.Random;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
public class ApplePay extends Payment {
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //variables
    private String applePayToken = ApplePayCodeGenerator();
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //constructors
    ApplePay() {
        super();
    }

    ApplePay(String paymentMethod) {
        super(paymentMethod);
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //setters and getters
    public String getApplePayToken(){
        return this.applePayToken;   
    }

//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    // Method to send a apple pay transaction confirmation message
    public static void sendApplePayConfirmationMessage(String phoneNum, String amount, String applePayToken) {
        System.out.println("----------------------------------------------------------------------");
        System.out.println("----------------------------------------------------------------------");
        System.out.println("Message to: " + phoneNum);
        System.out.println("----------------------------------------------------------------------");
        System.out.println("Apple Pay Transaction");
        System.out.println("----------------------------------------------------------------------");
        System.out.println("Transaction Details:");
        System.out.println(amount);
        System.out.println("Apple Pay Token: " + applePayToken);
        System.out.println("Merchant: Art Shop");
        System.out.println("----------------------------------------------------------------------");

    } 
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    private static String ApplePayCodeGenerator() {
        int codeLength = 10;
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder confirmationCode = new StringBuilder();

        Random random = new Random();
        for (int i = 0; i < codeLength; i++) {
            int index = random.nextInt(characters.length());
            confirmationCode.append(characters.charAt(index));
        }

        return confirmationCode.toString();
    }
} // end of Apple Pay class
