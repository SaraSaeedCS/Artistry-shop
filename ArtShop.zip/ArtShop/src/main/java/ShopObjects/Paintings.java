package ShopObjects;
import java.util.*;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
public class Paintings extends Services {
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //variables
    private String printed;
    private String paintType;
    private String size;
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //constructors 
    Paintings()
    {
        super();
        this.paintType = "";
        this.size = "";
    }
    
    Paintings(String serviceId, String name, double price, String printed, String paintType, String size) 
    {
        super(serviceId, name, price);
        this.printed = printed;
        this.paintType = paintType;
        this.size = size;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
        //setters and getters
    public String getPrinted() {
        return printed;
    }
    
    public void setPrinted(String printed){
        this.printed = printed;
    }
    
        public String getPaintType(){
        return paintType;
    }
        
    public void setPaintType(String plantType){
        this.paintType = plantType;
    }
    
    public String getSize(){
        return size;
    }
    
    public void setSize( String size  ){
        this.size = size;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    // Method to print the paintings menu
    public static void paintingsMenu(ArrayList<Paintings> paintings) {
        System.out.println("-- Paintings Menu --");

        int nameColumnWidth = 30;

        System.out.printf("%-15s%-"+ nameColumnWidth +"s%-15s%-10s%-15s%-25s%n",
                "Service Id", "Name", "Price (SR)", "Printed", "Paint Type", "Size");
        System.out.println("-----------------------------------------------------------------------------------------------------------------");

        for (Paintings p : paintings) {
            System.out.printf("%-15s%-"+ nameColumnWidth +"s%-15s%-10s%-15s%-25s%n",
                    p.serviceId, p.getName(), p.getPrice() + " SR",
                    p.getPrinted(), p.getPaintType(), p.getSize());
        }
        System.out.println("-----------------------------------------------------------------------------------------------------------------");
    }

//---------------------------------------------------------------------------------------------------------------------------------------------------------
    // Method to check if the entered painting ID is valid
    public static boolean isValidPaintingId(String paintingId, ArrayList<Paintings> paintings) {
        for (Paintings painting : paintings) {
            if (painting.serviceId.equals(paintingId)) {
                return true;
            }
        }
        return false;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
} //end of Paintings class.
