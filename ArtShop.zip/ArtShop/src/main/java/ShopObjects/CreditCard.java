package ShopObjects;

import java.time.LocalDate;
import java.util.Random;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
public class CreditCard extends Payment {
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    //variables
    private String cardNumber;
    private String expirationDate;
    private String transactionId = generateTransactionId();
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //constructors
    CreditCard() {
        super();
        this.cardNumber = "";
        this.expirationDate = "";
    }

    CreditCard(String paymentMethod, String cardNumber, String expirationDate) {
        super(paymentMethod);
        this.cardNumber = cardNumber;
        this.expirationDate = expirationDate;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //setters and getters
    public String getCardNumber() {
        return this.cardNumber;
    }

    public String getExpirationDate() {
        return this.expirationDate;
    }
    
    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public void setExpirationDate(String expirationDate) {
        this.expirationDate = expirationDate;
    }

    public String getTransactionId() {
        return transactionId;
    }
    
    
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    // Validation methods
    public static boolean isValidCreditCard(String cardNumber) {
        return cardNumber.length() == 16;
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    public static boolean isValidExpirationDate(String expirationDate) {
        int year, month;

        String[] dateParts = expirationDate.split("-");

        if (dateParts.length != 2) {
            return false;
        }

        if (!isNumeric(dateParts[0])) {
            return false;
        }
        year = Integer.parseInt(dateParts[0]);

        if (!isNumeric(dateParts[1])) {
            return false;
        }
        month = Integer.parseInt(dateParts[1]);

        // Validate the date
        LocalDate currentDate = LocalDate.now();
        LocalDate expDate = LocalDate.of(year, month, 1); // Assuming day is always 01

        return expDate.isAfter(currentDate) || expDate.isEqual(currentDate);
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    // check if a string is numeric
    public static boolean isNumeric(String str) {
        return str.matches("\\d+");
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
 // Method to send a credit card transaction confirmation email
    public static void sendCreditCardConfirmationEmail(String userEmail, String amount, String transactionId) {
        System.out.println("----------------------------------------------------------------------");
        System.out.println("----------------------------------------------------------------------");
        System.out.println("Sending credit card transaction confirmation email to: " + userEmail);
        System.out.println("----------------------------------------------------------------------");
        System.out.println("Transaction Details:");
        System.out.println(amount);
        System.out.println("Transaction ID: " + transactionId);
        System.out.println("Merchant: Art Shop");
        System.out.println("----------------------------------------------------------------------");

    }   
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    private static String generateTransactionId() {
        int idLength = 10;
        String characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder transactionId = new StringBuilder();

        Random random = new Random();
        for (int i = 0; i < idLength; i++) {
            int index = random.nextInt(characters.length());
            transactionId.append(characters.charAt(index));
        }

        return transactionId.toString();
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------
} //end of Credit Card class
