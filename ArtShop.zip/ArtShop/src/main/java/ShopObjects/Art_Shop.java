package ShopObjects;

import java.util.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
//---------------------------------------------------------------------------------------------------------------------------------------------------------
public final class Art_Shop {
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
    public static ArrayList<Event> events;
    public static ArrayList<Paintings>paintings;
    public static ArrayList<Supplies>supplies;
    public static ArrayList<Order> orders;
    
    public Art_Shop(){
    this.initializeCustomers();
    this.initializeEmployees();
    this.initializePaintings();
    this.initializeEvents();
    this.initializeSupplies();
    }
    public void initializePaintings(){
        paintings = new ArrayList<>(); // ArrayList to store paintings
        paintings.add(new Paintings("001", "Mona Lisa", 150, "No", "Oil", "20x16"));
        paintings.add(new Paintings("002","The Starry Night",200,"No","oil","20x40"));
        paintings.add(new Paintings("003","Starry Night Over The Rhone",180,"No","oil","24x36"));
        paintings.add(new Paintings("004","Irises In Monets Garden",160,"Yes","ink","18x24"));
        paintings.add(new Paintings("005","Branches with Almond Blossom",150,"No","oil","18x24"));
        paintings.add(new Paintings("006","The Water Lily Pond",140,"No","watercolor","24x24"));
        paintings.add(new Paintings("007","Impression, Sunrise",120,"No","acrylic","24x24"));
        paintings.add(new Paintings("008","Bedroom in Arles",120,"No","oil","18x24"));}
//---------------------------------------------------------------------------------------------------------------------------------------------------------
        public void initializeEvents(){   events = new ArrayList<>(); // ArrayList to store events
        events.add(new Event("101","Art Class",  35, "No", "Yes",2024,5,20));
        events.add(new Event("102","Student Showcase",30,"No","No",2024,5,20));
        events.add(new Event("103","Group Art Wall",0,"Yes","No",2024,5,21));
        events.add(new Event("104","Artist's Hangout",40,"No","No",2024,5,21));
        events.add(new Event("105","Mini Masters Workshop",25,"No","Yes",2024,5,21));}
//---------------------------------------------------------------------------------------------------------------------------------------------------------
        public void initializeSupplies()
{
        supplies = new ArrayList<>(); // ArrayList to store supplies
        supplies.add(new Supplies("201", "Paint Brush", 20, "Winsor & Newton", "Acrylic", "Beginner"));
        supplies.add(new Supplies("202", "Canvas", 45, "Winsor & Newton", "Oil", "Professional"));
        supplies.add(new Supplies("203", "Brush Set" , 100.00, "Derwent", "Oil", "Professional" ));
        supplies.add(new Supplies("204", "Watercolor Set" ,70.00 , "Koi", "Watercolor", "Beginner"));
        supplies.add(new Supplies("205", "Small Brush" ,  20.00, "Koi", "Watercolor", "Beginner"));}
//---------------------------------------------------------------------------------------------------------------------------------------------------------
        public void initializeCustomers(){
        ArrayList<Customer> customers = new ArrayList<>(); // ArrayList to store customers
        customers.add(new Customer("7777", "Leen", "LB222", "leen@gmail.com", "0577777777", "Khobar", "Yes"));
        customers.add(new Customer("1111", "Dalia", "DM222", "dalia@gmail.com", "0555555555", "Riyadh", "Yes"));
        customers.add(new Customer("4444", "Asma", "AJ222", "asma@gmail.com", "0511111111", "Dammam", "No"));
        customers.add(new Customer("3333", "Hala", "HS222", "hala@gmail.com", "0533333333", "Dammam", "No"));
        customers.add(new Customer("6666", "Lama", "LA222", "lama@gmail.com", "0566666666", "Dhahran", "No"));}
//---------------------------------------------------------------------------------------------------------------------------------------------------------
        public void initializeEmployees(){
        ArrayList<Employee> employees = new ArrayList<>();
     // ArrayList to store employees
        employees.add(new Employee("m1",  "Munerah", "MS222","munerah@gmail.com", "0508882222", "Dhahran", "Manager", 7500));
        employees.add(new Employee("02",  "Taymaa", "TD222","taymaa@gmail.com", "0554321098", "Dhahran", "Art Appraisal", 7500));
        employees.add(new Employee("03",  "Fatimah", "FH222","fatimahH@gmail.com", "0532109876", "Dhahran", "Technology and IT Support", 7500));
        employees.add(new Employee("04",  "Fatimah", "FM222","fatimahM@gmail.com", "0567890123", "Dhahran", "Content Creation", 7500));
        employees.add(new Employee("05",  "Raneem", "RM222","raneem@gmail.com", "0578901234", "Dhahran", "Sales and Customer Service", 7500));
        employees.add(new Employee("06",  "Hanan", "HS222","hanan@gmail.com", "0523456789", "Dhahran", "Marketing and Promotion", 7500));
        employees.add(new Employee("07",  "Aldanah", "AM222","aldanah@gmail.com", "0598765432", "Dhahran", "Gallery Management", 7500));
//
    }
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------
    /*public static void main(String[] args) {
        Scanner input = new Scanner(System.in); // for user input
//---------------------------------------------------------------------------------------------------------------------------------------------------------
        
        orders = new ArrayList<>();
        
    }}

        //int choice;
       /* do {
            System.out.println("-------------------------------------------------------------------------------"
            + "-------------------------------------------------------------------------------\nArt Shop");
            System.out.println("1. Customer Sign up\n2. Customer Login\n3. Employee Login\n0. Exit\nOur customer's ordering experiences have an average rating of " + Order.getAverageRating() + " out of 5!"); // menu when u first run the program

            // Validate input for menu choice
            while (!input.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                input.next(); 
            }
            choice = input.nextInt();
            input.nextLine(); 

            switch (choice) {
                case 1: //customer sign-up process
                    Customer.signUp(input, customers);
                    break;
                case 2: // customer log-in process
                    Customer loggedInCustomer = Customer.login(input, customers);

                    if (loggedInCustomer != null) {
                        int customerChoice;
                        Order order = new Order();

                        do {
                            // Displaying the customer menu
                            System.out.println("---------------------------------------------------------------"
                                    + "-----------------------------------------------------------------\nArt Shop");
                            System.out.println("Customer Menu\n1. Services\n2. Cart\n3. Confirm Order\n4. Update Information\n0. Exit");

                            // Validate input for menu choice
                            while (!input.hasNextInt()) {
                                System.out.println("Invalid input. Please enter a number.");
                                input.next(); // consume the invalid input
                            }

                            customerChoice = input.nextInt();
                            input.nextLine();

                            switch (customerChoice) {
                                case 1:
                                    // Services menu
                                    int serviceChoice;
                                    do {
                                        System.out.println("- Services -\n1. Events\n2. Paintings\n3. Supplies\n0. Exit");

                                        // Validate input for service choice
                                        while (!input.hasNextInt()) {
                                            System.out.println("Invalid input. Please enter a number.");
                                            input.next();
                                        }
                                        serviceChoice = input.nextInt();

                                        switch (serviceChoice) {
                                            case 1:
                                                order.getCart().addEventToCart(input, events); //add event to cart
                                                break;

                                            case 2:
                                                order.getCart().addPaintingToCart(input, paintings); //add painting to cart
                                                break;


                                            case 3:
                                                order.getCart().addSuppliesToCart(input, supplies); //add supplies to cart
                                                break;
   
                                            case 0:
                                                break;

                                            default:
                                                System.out.println("Invalid Entry. Please choose 1, 2, 3, or 0.");
                                        }

                                        input.nextLine();

                                    } while (serviceChoice != 0);
                                    break;


                                case 2:
                                    // Cart menu
                                    int editCart;
                                    do {
                                        System.out.println("- Cart -");

                                        System.out.println("Items: " + order.getCart().getItems());
                                        System.out.println("Number of Items: " + order.getCart().getNumOfItems());
                                        System.out.println("Total Amount: " + order.getCart().getTotal());
                                        System.out.println("-------------------------------------------------");

                                        System.out.println("Do you want to remove an item or clear the cart?\n1. Remove an item\n2. Clear\n0. No (close the cart)");

                                        // Handle invalid input
                                        while (!input.hasNextInt()) {
                                            System.out.println("Invalid input. Please enter a valid number.");
                                            input.next(); // Consume the invalid input
                                        }

                                        editCart = input.nextInt();

                                        switch (editCart) {
                                            case 1:
                                                System.out.println("Enter the service ID of the item you want to remove: ");
                                                String serID = input.next();

                                                // Check which list the service ID belongs to
                                                boolean idFound = false;

                                                for (Event event : events) {
                                                    if (event.serviceId.equals(serID)) {
                                                        order.getCart().removeItem(serID, events);
                                                        idFound = true;
                                                        break;
                                                    }
                                                }

                                                if (!idFound) {
                                                    for (Paintings painting : paintings) {
                                                        if (painting.serviceId.equals(serID)) {
                                                            order.getCart().removeItem(serID, paintings);
                                                            idFound = true;
                                                            break;
                                                        }
                                                    }
                                                }

                                                if (!idFound) {
                                                    for (Supplies supply : supplies) {
                                                        if (supply.serviceId.equals(serID)) {
                                                            order.getCart().removeItem(serID, supplies);
                                                            idFound = true;
                                                            break;
                                                        }
                                                    }
                                                }

                                                if (!idFound) {
                                                    System.out.println("Invalid service ID. Please enter a valid ID.");
                                                } else {
                                                    System.out.println("Item removed from the cart.");
                                                }
                                                break;
                                            case 2:
                                                order.getCart().clearCart();
                                                System.out.println("Cart cleared.");
                                                break;
                                            case 0:
                                                break;
                                            default:
                                                System.out.println("Invalid Entry");
                                        }

                                    } while (editCart != 0);

                                    break;
                                case 3:
                                    // Order handling code
                                    if (order.getCart().getNumOfItems() > 0) {
                                        System.out.println("- Confirming Order -");
                                        
                                        
                                    System.out.println("Choose the payment method you prefer:\n1. Credit Card\n2. Apple Pay\n0. Cancel");

                                    int paymentChoice;
                                    while (true) {
                                        // Validate payment choice input
                                        if (input.hasNextInt()) {
                                            paymentChoice = input.nextInt();
                                            if (paymentChoice == 1 || paymentChoice == 2 || paymentChoice == 0) {
                                                break;
                                            } else {
                                                System.out.println("Invalid input. Please enter 1, 2, or 0.");
                                            }
                                        } else {
                                            System.out.println("Invalid input. Please enter a valid number.");
                                            input.next(); // consume the invalid input
                                        }
                                    }

                                    if (paymentChoice != 0) {
                                        while (true) {
                                            if (paymentChoice == 1) {
                                                order.setPayment(new CreditCard());
                                                order.payment.setPaymentMethod("Credit Card");
                                                // Set Credit Card details
                                                System.out.println("Enter Credit Card Number:");
                                                String cardNumber = input.next();
                                                System.out.println("Enter Expiration Date (yyyy-mm):");
                                                String expirationDate = input.next();

                                                // Validate credit card details
                                                if (CreditCard.isValidCreditCard(cardNumber) && CreditCard.isValidExpirationDate(expirationDate)) {
                                                    ((CreditCard) order.getPayment()).setCardNumber(cardNumber);
                                                    ((CreditCard) order.getPayment()).setExpirationDate(expirationDate);
                                                    break; // Break the loop if credit card details are valid
                                                } else {
                                                    System.out.println("Invalid credit card details. Please try again.");
                                                    // Allow the user to try again
                                                }
                                            } else if (paymentChoice == 2) {
                                                order.setPayment(new ApplePay());
                                                order.payment.setPaymentMethod("Apple Pay");

                                                // Set Apple Pay details
                                                int phonePassword;
                                                do {
                                                    System.out.println("Enter your Phone Password (4 digits):");
                                                    while (!input.hasNextInt()) {
                                                        System.out.println("Please enter a valid integer.");
                                                        input.next(); // consume the invalid input
                                                    }
                                                    phonePassword = input.nextInt();
                                                } while (phonePassword >= 1000 && phonePassword <= 9999);

                                                break; // Break the loop for Apple Pay
                                            }

                                        }

                                        // Check if the user wants delivery
                                        System.out.println("What do you prefer? (1. Delivery / 2. Pick-up at shop)");
                                        int deliveryChoice;
                                        while (true) {
                                            // Validate delivery choice input
                                            if (input.hasNextInt()) {
                                                deliveryChoice = input.nextInt();
                                                if (deliveryChoice == 1 || deliveryChoice == 2) {
                                                    break;
                                                } else {
                                                    System.out.println("Invalid input. Please enter 1 or 2.");
                                                }
                                            } else {
                                                System.out.println("Invalid input. Please enter a valid number.");
                                                input.next(); // consume the invalid input
                                            }
                                        }

                                            if (loggedInCustomer.getMembership().equals("Yes")) {
                                                // Customer has membership
                                                if (deliveryChoice == 1) { // has membership wants delivery
                                                    // set up delivery date for members (3 days)
                                                    order.setDelivery(new Delivery());
                                                    LocalDate currentDate = LocalDate.now();
                                                    LocalDate newDeliveryDate = currentDate.plusDays(3);
                                                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                                                    String deliveryDateStr = newDeliveryDate.format(formatter);
                                                    order.getDelivery().setDeliveryDate(deliveryDateStr);
                                                    order.getDelivery().setDeliveryAddress(loggedInCustomer.getAddress());
                                                    order.getCart().setTotal(order.getPayment().discount(order.getCart()) + 10);
                                                    order.collectCustomerRating();
                                                    orders.add(order);
                                                    Order.calculateAverageRating(orders);



                                                } else if (deliveryChoice == 2) { // has membership doesnt want delivery
                                                    // set up pick-up at store for members
                                                    order.setDelivery(new Delivery());
                                                    order.getDelivery().deliveryPreference = "Pick-up at Store";
                                                    order.getDelivery().setDeliveryDate("Pick-up at Store");
                                                    order.getDelivery().setDeliveryAddress("Pick-Up at Store");
                                                    order.getCart().setTotal(order.getPayment().discount(order.getCart()));
                                                    order.collectCustomerRating();
                                                    orders.add(order);
                                                    Order.calculateAverageRating(orders);

                                                }
                                            } else if (loggedInCustomer.getMembership().equals("No")){
                                                // no membership wants delivery
                                                if (deliveryChoice == 1) {
                                                    // set up delivery date for non-members (14 days)
                                                    order.setDelivery(new Delivery());
                                                    LocalDate currentDate = LocalDate.now();
                                                    LocalDate newDeliveryDate = currentDate.plusDays(14);
                                                    DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                                                    String deliveryDateStr = newDeliveryDate.format(formatter);
                                                    order.getDelivery().setDeliveryDate(deliveryDateStr);
                                                    order.getDelivery().setDeliveryAddress(loggedInCustomer.getAddress());
                                                    order.getCart().setTotal(order.getPayment().discount(order.getCart()));
                                                    order.collectCustomerRating();
                                                    orders.add(order);
                                                    Order.calculateAverageRating(orders);
                                                
                                                } else if (deliveryChoice == 2) { // no membership doesnt want delivery
                                                    // set up pick-up at store for non-members
                                                    order.setDelivery(new Delivery());
                                                    order.getDelivery().deliveryPreference = "Pick-up at Store";
                                                    order.getDelivery().setDeliveryDate("Pick-up at Store");
                                                    order.getDelivery().setDeliveryAddress("Pick-Up at Store");
                                                    order.getCart().setTotal(order.getPayment().discount(order.getCart()));
                                                    order.collectCustomerRating();
                                                    orders.add(order);
                                                    Order.calculateAverageRating(orders);

                                                }
                                            }


                                        // Confirm the order
                                        System.out.println("--------------------------------------------------------------------------------------------------------------------------------");
                                        System.out.println("Order confirmed!");

                                        // Print receipt
                                        order.getReceipt(loggedInCustomer);
                                        order.getCart().clearCart();
                                        
                                        System.out.println("----------------------------------------------------------------------");

                                    } else {
                                        System.out.println("Order canceled.");     
                                    }
                                    }
                                    else {
                                        System.out.println("\nyour cart is empty...");
                                    }
                                    break;
                                case 4:
                                    // Update information handling code
                                    System.out.println("- Update Info -");
                                    loggedInCustomer.updateInformationMenu(input);
                                    break;

                                case 0:
                                    // Exiting the program
                                    System.out.println("Exiting the program. Goodbye!");
                                    break;

                                default:
                                    // Dealing with incorrect choice input
                                    System.out.println("Invalid choice. Please choose 1, 2, 3, or 0.");
                            }
                        } while (customerChoice != 0);
                    }
                    break;
                
                case 3: // employee log-in process
                    System.out.println("Enter employee ID: ");
                    String enteredEmployeeId = input.nextLine();
                    System.out.println("Enter your password: ");
                    String enteredEmployeePassword = input.nextLine();

                    // Check if the entered userId exists in the Employee ArrayList
                    Employee loggedInEmployee = null;
                    for (Employee e : employees) {
                        if (e.getUserId().equals(enteredEmployeeId)) {
                            loggedInEmployee = e;
                            break;
                        }
                    }

                    if (loggedInEmployee != null) {
                        // Check if the entered password matches the stored password
                        if (enteredEmployeePassword.equals(loggedInEmployee.getPassword())) {
                            String empId = loggedInEmployee.getUserId();
                            if (empId.charAt(0) == 'm') {
                                System.out.println("Manager logged in! Welcome, " + loggedInEmployee.getName());
                                int managerChoice;
                                do {
                                    System.out.println("-------------------------------------------------------------------------------"
                                            + "-------------------------------------------------------------------------------\nArt Shop");
                                    System.out.println(
                                            "Manager Menu\n1. Add Service\n2. Update Service\n3. Delete Service\n4. Update Employee Information\n5. Update Information\n0. Exit");

                                    // Validate input for menu choice
                                    while (!input.hasNextInt()) {
                                        System.out.println("Invalid input. Please enter a number.");
                                        input.next(); // consume the invalid input
                                    }

                                    managerChoice = input.nextInt();
                                    input.nextLine(); // consume newline
                                    switch (managerChoice) {
                                        case 1:
                                            loggedInEmployee.addServiceMenu(input);
                                            break;

                                        case 2:
                                            loggedInEmployee.updateServiceMenu(input);
                                            break;

                                        case 3:
                                            loggedInEmployee.deleteServiceMenu(input);
                                            break;

                                        case 4:
                                            loggedInEmployee.updateEmployee(employees);
                                            break;

                                        case 5:
                                            loggedInEmployee.updateInformationMenu(input);
                                            break;

                                        case 0:
                                            break;

                                        default: // dealing with incorrect choice input
                                            System.out.println("Invalid choice. Please choose 1, 2, 3, 4, 5, or 0.");
                                            break;
                                    }

                                } while (managerChoice != 0);

                            } else {
                                System.out.println(
                                        "Login successful! Welcome, " + loggedInEmployee.getName() + " (" + loggedInEmployee.getDepartment() + ")");
                                int employeeChoice;
                                do {
                                    // Display main menu
                                    System.out.println("-------------------------------------------------------------------------------"
                                            + "-------------------------------------------------------------------------------\nArt Shop");
                                    System.out.println("Employee Menu\n1. Add Service\n2. Update Service\n3. Delete Service\n4. Update Information\n0. Exit");

                                    // Validate input for menu choice
                                    while (!input.hasNextInt()) {
                                        System.out.println("Invalid input. Please enter a number.");
                                        input.next(); // consume the invalid input
                                    }

                                    // Process menu choice
                                    employeeChoice = input.nextInt();
                                    input.nextLine(); // consume newline

                                    switch (employeeChoice) {
                                        case 1:
                                            loggedInEmployee.addServiceMenu(input);
                                            break;

                                        case 2:
                                            loggedInEmployee.updateServiceMenu(input);
                                            break;

                                        case 3:
                                            loggedInEmployee.deleteServiceMenu(input);
                                            break;

                                        case 4:
                                            loggedInEmployee.updateInformationMenu(input);
                                            break;

                                        case 0:
                                            break;

                                        default: // dealing with incorrect choice input
                                            System.out.println("Invalid choice. Please choose 1, 2, 3 or 0.");
                                            break;
                                    }
                                } while (employeeChoice != 0);

                            }

                        } else {
                            System.out.println("Incorrect password. Please try again.");
                        }

                    } else {
                        System.out.println("Employee ID not found. Please check your credentials.");
                    }
                    break; // Add this break statement to exit the switch block

                case 0: // exiting the program
                    System.out.println("Exiting the program. Goodbye!");
                    break; // Add this break statement to exit the switch block

                default: // dealing with incorrect choice input
                    System.out.println("Invalid choice. Please choose 1, 2, 3 or 0.");
                    break; // Add this break statement to exit the switch block

            }
        } while (choice != 0);
//---------------------------------------------------------------------------------------------------------------------------------------------------------        
    } // end of Main 
//---------------------------------------------------------------------------------------------------------------------------------------------------------
    //method to print employees
    public static void employeeList(ArrayList<Employee> employees) {
        System.out.println("-- Employee List --");
        System.out.printf("%-10s%-20s%-30s%-15s%-20s%-30s%-10s%n",
                "User ID", "Name", "Email", "Phone Number", "Address", "Department", "Salary");
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");

        for (Employee e : employees) {
            System.out.printf("%-10s%-20s%-30s%-15s%-20s%-30s%-10s%n",
                    e.getUserId(), e.getName(), e.getEmail(), e.getPhoneNum(),
                    e.getAddress(), e.getDepartment(), e.getSalary() + " SR");
        }
        System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
    }
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
// Method to print events
public static void eventsList(ArrayList<Event> events) {
    System.out.printf("%-10s%-20s%-15s%-20s%-30s%-10s%n", "ServiceID", "Name", "Price", "Free", "Online", "Date");
    for (Event e : events) {
        System.out.printf("%-10s%-20s%-15s%-20s%-30s%-10s%n",
                e.serviceId, e.getName(), e.getPrice() + " SR",
                e.getFree(), e.getOnline(), e.getDate());
    }
    System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
}

// Method to print paintings
public static void paintingsList(ArrayList<Paintings> paintings) {
    System.out.printf("%-10s%-20s%-15s%-20s%-30s%-10s%n", "ServiceID", "Name", "Price", "Printed", "PaintType", "Size");
    for (Paintings e : paintings) {
        System.out.printf("%-10s%-20s%-15s%-20s%-30s%-10s%n",
                e.serviceId, e.getName(), e.getPrice() + " SR",
                e.getPrinted(), e.getPaintType(), e.getSize());
    }
    System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
}

// Method to print supplies
public static void suppliesList(ArrayList<Supplies> supplies) {
    System.out.printf("%-10s%-20s%-15s%-20s%-30s%-10s%n", "ServiceID", "Name", "Price", "Brand", "TypeOfMedium", "ProfessionalOrBeginner");
    for (Supplies e : supplies) {
        System.out.printf("%-10s%-20s%-15s%-20s%-30s%-10s%n",
                e.serviceId, e.getName(), e.getPrice() + " SR",
                e.getBrand(), e.getTypeOfMedium(), e.getProfessionalOrBeginner());
    }
    System.out.println("---------------------------------------------------------------------------------------------------------------------------------------");
} *
//---------------------------------------------------------------------------------------------------------------------------------------------------------    
} // end of Art_Shop class.*/
       
    
