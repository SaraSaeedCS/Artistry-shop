package ShopObjects;

import java.util.*;
public class Employee extends User {
//------------------------------------------------------------------------------//------------------------------------------------------------------------------    
    //variables
    private String department;
    private double salary;
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
    //constructors    
    public Employee() {
    
    }   
          
    public Employee(String userId,  String name, String password,String email, String phoneNum, String address, String department, double salary) {
        super(userId, name, password, email, phoneNum, address);
        this.department = department;
        this.salary = salary;
        }  

//------------------------------------------------------------------------------//------------------------------------------------------------------------------
    //setters and getters
 /*   public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        this.salary = salary;
    }   
//------------------------------------------------------------------------------//------------------------------------------------------------------------------        
   // method to display the employee menu
    public void displayMenu(){
    Scanner input = new Scanner(System.in);
    System.out.println("Login successful! Welcome, " + getName() +
            " (" + getDepartment() + ")");
    int employeeChoice;
    do {
        System.out.println("--------------------------------------------------------------------------------------------------------------------------------------------------------------\nArt Shop");
        System.out.println("Employee Menu\n1. Add Service\n2. Update Service\n3. Delete Service\n4. Update Information\n0. Exit");

        // Validate input for menu choice
        while (!input.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            input.next();
        }

        employeeChoice = input.nextInt();
        input.nextLine(); 

        switch (employeeChoice) {
            case 1:
                addServiceMenu(input);
                break;
            case 2:
                updateServiceMenu(input);
                break;
            case 3:
                deleteServiceMenu(input);
                break;
            case 4:
                updateInformationMenu(input);
                break;
            case 0:
                break;
            default:
                System.out.println("Invalid choice. Please choose 1, 2, 3, 4, or 0.");
                break;
        }
    } while (employeeChoice != 0);
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------        
    // method for employee or manager to add a specific service
    public void addServiceMenu(Scanner input) {
    System.out.println("Choose the type of service you want to add: ");
    int addedServiceChoice;
    do {
        System.out.println("\n1. Events\n2. Paintings\n3. Supplies\n0. Exit");
        addedServiceChoice = input.nextInt();
        input.nextLine();

        switch (addedServiceChoice) {

            case 1:
                Event.eventMenu(Art_Shop.events);  // Display the list of events
                addEvent(input);
                break;

            case 2:
                Paintings.paintingsMenu(Art_Shop.paintings); // Display the list of paintings
                addPainting(input);
                break;

            case 3:
                Supplies.suppliesMenu(Art_Shop.supplies); // Display the list of supplies
                addSupplies(input);
                break;

            case 0:
                break;

            default:
                System.out.println("Invalid Entry");
                break;
        }
    } while (addedServiceChoice != 0);
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
   // method for employee or manager to update a specific service
    public void updateServiceMenu(Scanner input) {
        System.out.println("Choose the type of service you want to update: ");
        int updatedServiceChoice;
        do {
            System.out.println("\n1. Events\n2. Paintings\n3. Supplies\n0. Exit");
            updatedServiceChoice = input.nextInt();

            switch (updatedServiceChoice) {
                case 1:
                    // Update event
                    Event.eventMenu(Art_Shop.events);  // Display the list of events
                    updateEvent(Art_Shop.events);
                    break;
                case 2:
                    // Update painting
                    Paintings.paintingsMenu(Art_Shop.paintings);  // Display the list of events
                    updatePainting(Art_Shop.paintings);
                    break;
                case 3:
                    // Update supply
                    Supplies.suppliesMenu(Art_Shop.supplies);  // Display the list of events
                    updateSupplies(Art_Shop.supplies);
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Invalid Entry");
                    break;
            }
        } while (updatedServiceChoice != 0);
    }
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
   //method for employee or manager to delete a specific service
    public void deleteServiceMenu(Scanner input) {
        System.out.println("Choose the type of service you want to delete: ");
        int deletedServiceChoice;
        do {
            System.out.println("\n1. Events\n2. Paintings\n3. Supplies\n0. Exit");
            deletedServiceChoice = input.nextInt();

            switch (deletedServiceChoice) {
                case 1:
                    // Delete event
                    Event.eventMenu(Art_Shop.events);  // Display the list of events
                    deleteEvent(Art_Shop.events);
                    break;
                case 2:
                    // Delete painting
                    Paintings.paintingsMenu(Art_Shop.paintings);  // Display the list of events
                    deletePainting(Art_Shop.paintings);
                    break;
                case 3:
                    // Delete supply
                    Supplies.suppliesMenu(Art_Shop.supplies);  // Display the list of events
                    deleteSupplies(Art_Shop.supplies);
                    break;
                case 0:
                    break;
                default:
                    System.out.println("Invalid Entry");
                    break;
            }
        } while (deletedServiceChoice != 0);
    }
//------------------------------------------------------------------------------//------------------------------------------------------------------------------       
    // method for manager to update employee information
public void updateEmployee(ArrayList<Employee> employees) {
    Scanner input = new Scanner(System.in);
    Art_Shop.employeeList(employees); // Display the list of employees
    System.out.println("Enter the user ID of the employee you want to update (Enter '0' to cancel): ");
    String userIdToUpdate = input.nextLine();

    // Check if the user wants to cancel the update
    if (userIdToUpdate.equals("0")) {
        System.out.println("Update process canceled.");
        return;
    }

    // Find the employee with the given user ID
    Employee selectedEmployee = null;
    for (Employee employee : employees) {
        if (employee.getUserId().equals(userIdToUpdate)) {
            selectedEmployee = employee;
            break;
        }
    }

    // Check if the employee was found
    if (selectedEmployee != null) {
        // Display the current information of the selected employee
        System.out.println("Current Information for " + selectedEmployee.getName());
        System.out.println("1. Department: " + selectedEmployee.getDepartment());
        System.out.println("2. Salary: " + selectedEmployee.getSalary() + "SR");
        System.out.println("0. Exit");

        // Get the update choice from the user
        int updateChoice;
        do {
            System.out.println("Choose the information to update (1, 2, or 0 to exit): ");
            while (!input.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                input.next(); 
            }
            updateChoice = input.nextInt();
            input.nextLine(); 

            switch (updateChoice) {
                case 1:
                    System.out.println("Enter the new department: ");
                    String newDepartment = input.nextLine();
                    selectedEmployee.setDepartment(newDepartment);
                    System.out.println("Department updated successfully.");
                    break;
                case 2:
                    System.out.println("Enter the new salary: ");
                    while (!input.hasNextDouble()) {
                        System.out.println("Invalid input. Please enter a valid salary.");
                        input.next(); 
                    }
                    double newSalary = input.nextDouble();
                    selectedEmployee.setSalary(newSalary);
                    System.out.println("Salary updated successfully.");
                    break;
                case 0:
                    System.out.println("Exiting update process.");
                    break;
                default:
                    System.out.println("Invalid choice. Please choose 1, 2, or 0.");
                    break;
            }
        } while (updateChoice != 0);
    } else {
        System.out.println("Employee with User ID " + userIdToUpdate + " not found.");
    }
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------    
public void addEvent(Scanner input) {
    System.out.println("Enter '0' at any time to cancel the event creation process.");

    String eId;
    while (true) {
        System.out.println("Enter the service ID of the event (3 digits, higher than 100 and lower than 200): ");
        eId = input.nextLine();
        if (eId.equals("0")) {
            System.out.println("Event creation canceled.");
            return;
        }
        if (isValidEventId(eId)) {
            break;
        }
        System.out.println("Invalid input. Please enter a valid service ID for events.");
    }

    String eN;
    while (true) {
        System.out.println("Enter the name of the event: ");
        eN = input.nextLine();
        if (eN.equals("0")) {
            System.out.println("Event creation canceled.");
            return;
        }
        if (isValidWordsWithSpaces(eN)) {
            break;
        }
        System.out.println("Invalid input. Please enter a valid name.");
    }

    double eP;
    while (true) {
        System.out.println("Enter the price of the ticket: ");
        if (input.hasNextDouble()) {
            eP = input.nextDouble();
            break;
        } else {
            String userInput = input.nextLine();
            if (userInput.equals("0")) {
                System.out.println("Event creation canceled.");
                return;
            }
            System.out.println("Invalid input. Please enter a valid price.");
        }
    }

    input.nextLine();

    String eF;
    while (true) {
        System.out.println("Is the event free?\n1. Yes\n2. No ");
        eF = input.nextLine();
        if (eF.equals("0")) {
            System.out.println("Event creation canceled.");
            return;
        }
        if (isValidYesNo(eF)) {
            break;
        }
        System.out.println("Invalid input. Please enter 1 for Yes or 2 for No.");
    }

    String isEventFree = eF.equals("1") ? "Yes" : "No";

    String eO;
    while (true) {
        System.out.println("Is the event online?\n1. Yes\n2. No ");
        eO = input.nextLine();
        if (eO.equals("0")) {
            System.out.println("Event creation canceled.");
            return;
        }
        if (isValidYesNo(eO)) {
            break;
        }
        System.out.println("Invalid input. Please enter 1 for Yes or 2 for No.");
    }

    String isEventOnline = eO.equals("1") ? "Yes" : "No";

    String eD;
    while (true) {
        System.out.println("Enter the date of the event: ");
        eD = input.nextLine();
        if (eD.equals("0")) {
            System.out.println("Event creation canceled.");
            return;
        }
        if (isValidString(eD)) {
            break;
        }
        System.out.println("Invalid input. Please enter a valid string.");
    }

    Art_Shop.events.add(new Event(eId, eN, eP, isEventFree, isEventOnline, eD));
    System.out.println("Event created successfully.");
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
public void addPainting(Scanner input) {
    System.out.println("Enter '0' at any time to cancel the painting creation process.");

    String pId;
    while (true) {
        System.out.println("Enter the service ID of the painting (3 digits, higher than 000 and lower than 100): ");
        pId = input.nextLine();
        if (pId.equals("0")) {
            System.out.println("Painting creation canceled.");
            return;
        }
        if (isValidPaintingId(pId)) {
            break;
        }
        System.out.println("Invalid input. Please enter a valid service ID for paintings.");
    }

    String pN;
    while (true) {
        System.out.println("Enter the name of the painting: ");
        pN = input.nextLine();
        if (pN.equals("0")) {
            System.out.println("Painting creation canceled.");
            return;
        }
        if (isValidWordsWithSpaces(pN)) {
            break;
        }
        System.out.println("Invalid input. Please enter a valid name.");
    }

    double pP;
    while (true) {
        System.out.println("Enter the price of the painting: ");
        if (input.hasNextDouble()) {
            pP = input.nextDouble();
            break;
        } else {
            String userInput = input.nextLine();
            if (userInput.equals("0")) {
                System.out.println("Painting creation canceled.");
                return;
            }
            System.out.println("Invalid input. Please enter a valid price.");
        }
    }

    input.nextLine();

    String pPr;
    while (true) {
        System.out.println("Is the painting printed?\n1. Yes\n2. No ");
        pPr = input.nextLine();
        if (pPr.equals("0")) {
            System.out.println("Painting creation canceled.");
            return;
        }
        if (isValidYesNo(pPr)) {
            break;
        }
        System.out.println("Invalid input. Please enter 1 for Yes or 2 for No.");
    }

    String pPt;
    if (pPr.equals("1")) {
        // Painting is printed, set printed to "Yes"
        pPr = "Yes";
        // Set paint type to "Ink" for printed paintings
        pPt = "Ink";
    } else {
        // Painting is not printed, let the user choose the paint type
        System.out.println("Enter the paint type of the painting (Ink, Oil, Acrylic, Watercolor): ");
        pPt = input.nextLine();
        while (!isValidPaintType(pPt)) {
            String userInput = input.nextLine();
            if (userInput.equals("0")) {
                System.out.println("Painting creation canceled.");
                return;
            }
            System.out.println("Invalid input. Please enter a valid paint type (Oil, Acrylic, Watercolor).");
            pPt = input.nextLine();
        }
        // Set printed to "No" for non-printed paintings
        pPr = "No";
    }

    String pS;
    while (true) {
        System.out.println("Enter the size of the painting (enter '0' to cancel): ");
        pS = input.nextLine();

        if (pS.equals("0")) {
            System.out.println("Painting creation canceled.");
            return;
        }

        if (isValidSize(pS)) {
            break;
        }

        System.out.println("Invalid input. Please enter a valid size (e.g., 24x12).");
    }

    Art_Shop.paintings.add(new Paintings(pId, pN, pP, pPr, pPt, pS));
    System.out.println("Painting created successfully.");
}

// validate paint type
private boolean isValidPaintType(String input) {
    return input.equalsIgnoreCase("Ink") ||input.equalsIgnoreCase("Oil") || input.equalsIgnoreCase("Acrylic") || input.equalsIgnoreCase("Watercolor");
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
public void addSupplies(Scanner input) {
    System.out.println("Enter '0' at any time to cancel the supply creation process.");

    String sId;
    while (true) {
        System.out.println("Enter the service ID of the supply (3 digits, higher than 200 and lower than 300): ");
        sId = input.nextLine();
        if (sId.equals("0")) {
            System.out.println("Supply creation canceled.");
            return;
        }
        if (isValidSupplyId(sId)) {
            break;
        }
        System.out.println("Invalid input. Please enter a valid service ID for supplies.");
    }

    String sN;
    while (true) {
        System.out.println("Enter the name of the supply: ");
        sN = input.nextLine();
        if (sN.equals("0")) {
            System.out.println("Supply creation canceled.");
            return;
        }
        if (isValidWordsWithSpaces(sN)) {
            break;
        }
        System.out.println("Invalid input. Please enter a valid name.");
    }

    double sP;
    while (true) {
        System.out.println("Enter the price of the supply: ");
        if (input.hasNextDouble()) {
            sP = input.nextDouble();
            break;
        } else {
            String userInput = input.nextLine();
            if (userInput.equals("0")) {
                System.out.println("Supply creation canceled.");
                return;
            }
            System.out.println("Invalid input. Please enter a valid price.");
        }
    }

    input.nextLine();

    String sB;
    while (true) {
        System.out.println("Enter the brand of the supply: ");
        sB = input.nextLine();
        if (sB.equals("0")) {
            System.out.println("Supply creation canceled.");
            return;
        }
        if (isValidWordsWithSpaces(sB)) {
            break;
        }
        System.out.println("Invalid input. Please enter a valid brand.");
    }

    String sToM;
    while (true) {
        System.out.println("Enter the type of medium of the supply (Oil, Acrylic, Watercolor, General): ");
        sToM = input.nextLine();
        if (sToM.equals("0")) {
            System.out.println("Supply creation canceled.");
            return;
        }
        if (isValidMedium(sToM)) {
            break;
        }
        System.out.println("Invalid input. Please enter a valid type of medium.");
    }

    String sPorB;
    while (true) {
        System.out.println("Is the supply considered for professionals or beginners?\n1. Professionals\n2. Beginners ");
        sPorB = input.nextLine();
        if (sPorB.equals("0")) {
            System.out.println("Supply creation canceled.");
            return;
        }
        if (isValidYesNo(sPorB)) {
            sPorB = sPorB.equals("1") ? "Professional" : "Beginner";
            break;
        }
        System.out.println("Invalid input. Please enter 1 for Professionals or 2 for Beginners.");
    }

    Art_Shop.supplies.add(new Supplies(sId, sN, sP, sB, sToM, sPorB));
    System.out.println("Supply created successfully.");
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
// validate string
private boolean isValidString(String input) {
    return !input.trim().isEmpty();
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
// validate Yes/No input
private boolean isValidYesNo(String input) {
    return input.equals("1") || input.equals("2");
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
// validate event service ID
private boolean isValidEventId(String input) {
    if (input.length() == 3 && isInteger(input)) {
        int eventId = Integer.parseInt(input);

        if (eventId > 100 && eventId < 200) {
            // Check if the ID already exists in the events ArrayList
            for (Event event : Art_Shop.events) {
                if (event.serviceId.equals(input)) {
                    return false; // ID already exists
                }
            }
            return true; // ID is valid and does not exist
        }
    }
    return false;
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
// validate painting service ID
private boolean isValidPaintingId(String input) {
    if (input.length() == 3 && isInteger(input)) {
        int paintingId = Integer.parseInt(input);

        if (paintingId >= 0 && paintingId < 100) {
            // Check if the ID already exists in the paintings ArrayList
            for (Paintings painting : Art_Shop.paintings) {
                if (painting.serviceId.equals(input)) {
                    return false; // ID already exists
                }
            }
            return true; // ID is valid and does not exist
        }
    }
    return false;
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
// validate supply service ID
private boolean isValidSupplyId(String input) {
    if (input.length() == 3 && isInteger(input)) {
        int supplyId = Integer.parseInt(input);

        if (supplyId > 200 && supplyId < 300) {
            // Check if the ID already exists in the supplies ArrayList
            for (Supplies supply : Art_Shop.supplies) {
                if (supply.serviceId.equals(input)) {
                    return false; // ID already exists
                }
            }
            return true; // ID is valid and does not exist
        }
    }
    return false;
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
// check if a string is an integer
private boolean isInteger(String input) {
    Scanner scanner = new Scanner(input);
    return scanner.hasNextInt();
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
private boolean isValidWordsWithSpaces(String input) {
    // check if the string contains only words and spaces
    return input.matches("[a-zA-Z]+( [a-zA-Z]+)*");
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------            
    public void updateSupplies(ArrayList<Supplies> supplies) {
        Scanner input = new Scanner(System.in);
        String supplyIdToUpdate;

        // Get a valid service ID from the user
        while (true) {
            System.out.println("Enter the service ID of the Supply you want to update (Enter '0' to cancel): ");
            supplyIdToUpdate = input.nextLine();
            if (supplyIdToUpdate.equals("0")) {
                System.out.println("Update process canceled.");
                return;
            }
            if (isValidSupplyId(supplyIdToUpdate, supplies)) {
                break;
            }
            System.out.println("Invalid input. Please enter a valid service ID for supplies.");
        }

        // Find the supply with the given service ID
        Supplies selectedSupply = null;
        for (Supplies supply : supplies) {
            if (supply.serviceId.equals(supplyIdToUpdate)) {
                selectedSupply = supply;
                break;
            }
        }

        // Check if the supply was found
        if (selectedSupply != null) {
            // Display the current information of the selected supply
            System.out.println("Current Information for " + selectedSupply.serviceId);
            System.out.println("1. Name: " + selectedSupply.getName());
            System.out.println("2. Price: " + selectedSupply.getPrice() + "SR");
            System.out.println("3. Brand: " + selectedSupply.getBrand());
            System.out.println("4. Type of Medium: " + selectedSupply.getTypeOfMedium());
            System.out.println("5. Professional or beginner: " + selectedSupply.getProfessionalOrBeginner());
            System.out.println("0. Exit");

            // Get the update choice from the user
            int updateChoice;
            do {
                System.out.println("Choose the information to update (1, 2, 3, 4, 5, or 0 to exit): ");
                while (!input.hasNextInt()) {
                    System.out.println("Invalid input. Please enter a number.");
                    input.next(); // consume the invalid input
                }
                updateChoice = input.nextInt();
                input.nextLine(); // consume newline

                switch (updateChoice) {
                    case 1:
                        System.out.println("Enter the new name: ");
                        String newName;
                        do {
                            newName = input.nextLine();
                        } while (!isValidWordsWithSpaces(newName));
                        selectedSupply.setName(newName);
                        System.out.println("Name updated successfully.");
                        break;
                    
                    case 2:
                        System.out.println("Enter the new price: ");
                        double newPrice;
                        do {
                            while (!input.hasNextDouble()) {
                                System.out.println("Invalid input. Please enter a valid price.");
                                input.next(); 
                            }
                            newPrice = input.nextDouble();
                            input.nextLine(); 
                        } while (newPrice < 0); // Ensure price is non-negative
                        selectedSupply.setPrice(newPrice);
                        System.out.println("Price updated successfully.");
                        break;
                    case 3:
                        System.out.println("Enter the new brand: ");
                        String newBrand;
                        do {
                            newBrand = input.nextLine();
                        } while (!isValidWordsWithSpaces(newBrand));
                        selectedSupply.setBrand(newBrand);
                        System.out.println("Brand updated successfully.");
                        break;
                    case 4:
                        System.out.println("Enter the new Type of Medium (Oil, Acrylic, Watercolor, General): ");
                        String newMedium;
                        do {
                            newMedium = input.nextLine();
                        } while (!isValidMedium(newMedium));
                        selectedSupply.setTypeOfMedium(newMedium);
                        System.out.println("Type of Medium updated successfully.");
                        break;

                    case 5:
                        System.out.println("Enter the new category (Professionals or Beginners):\n1. Professionals\n2. Beginners");
                        String newCategory;
                        do {
                            newCategory = input.nextLine();
                        } while (!isValidYesNo(newCategory));

                        newCategory = newCategory.equals("1") ? "Professionals" : "Beginners";

                        selectedSupply.setProfessionalOrBeginner(newCategory);
                        System.out.println("Category updated successfully.");
                        break;
                }
            } while (updateChoice != 0);
        } else {
            System.out.println("Supply with Service ID " + supplyIdToUpdate + " not found.");
        }
    }
//------------------------------------------------------------------------------//------------------------------------------------------------------------------    
    // validate supply service ID
    private boolean isValidSupplyId(String input, ArrayList<Supplies> supplies) {
        if (input.length() == 3 && isInteger(input)) {
            int supplyId = Integer.parseInt(input);

            if (supplyId > 200 && supplyId < 300) {
                // Check if the ID already exists in the supplies ArrayList
                for (Supplies supply : supplies) {
                    if (supply.serviceId.equals(input)) {
                        return true; // ID exists
                    }
                }
            }
        }
        return false;
    }
//------------------------------------------------------------------------------//------------------------------------------------------------------------------    
// validate type of medium
private boolean isValidMedium(String input) {
    String[] validMediums = {"Oil", "Acrylic", "Watercolor", "General"};
    for (String medium : validMediums) {
        if (medium.equalsIgnoreCase(input.trim())) {
            return true;
        }
    }
    return false;
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------         
// updating painting method that is used in the updateServiceMenu method
public void updatePainting(ArrayList<Paintings> paintings) {
    Scanner input = new Scanner(System.in);
    String paintingIdToUpdate;

    // Get a valid painting ID from the user
    while (true) {
        System.out.println("Enter the service ID of the painting you want to update (Enter '0' to cancel): ");
        paintingIdToUpdate = input.nextLine();
        if (paintingIdToUpdate.equals("0")) {
            System.out.println("Update process canceled.");
            return;
        }
        if (isValidPaintingId(paintingIdToUpdate, paintings)) {
            break;
        }
        System.out.println("Invalid input. Please enter a valid service ID for paintings.");
    }

    // Find the painting with the given service ID
    Paintings selectedPainting = null;
    for (Paintings painting : paintings) {
        if (painting.serviceId.equals(paintingIdToUpdate)) {
            selectedPainting = painting;
            break;
        }
    }

    // Check if the painting was found
    if (selectedPainting != null) {
        // Display the current information of the selected painting
        System.out.println("Current Information for " + selectedPainting.serviceId);
        System.out.println("1. Name: " + selectedPainting.getName());
        System.out.println("2. Price: " + selectedPainting.getPrice() + "SR");
        System.out.println("3. Printed: " + selectedPainting.getPrinted());
        System.out.println("4. Paint Type: " + selectedPainting.getPaintType());
        System.out.println("5. Size: " + selectedPainting.getSize());
        System.out.println("0. Exit");

        // Get the update choice from the user
        int updateChoice;
        do {
            System.out.println("Choose the information to update (1, 2, 3, 4, 5, or 0 to exit): ");
            while (!input.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                input.next(); 
            }
            updateChoice = input.nextInt();
            input.nextLine();

            switch (updateChoice) {
                case 1:
                    System.out.println("Enter the new name: ");
                    String newName;
                    do {
                        newName = input.nextLine();
                    } while (!isValidWordsWithSpaces(newName));
                    selectedPainting.setName(newName);
                    System.out.println("Name updated successfully.");
                    break;
                    
                case 2:
                    System.out.println("Enter the new price: ");
                    double newPrice;
                    do {
                        while (!input.hasNextDouble()) {
                            System.out.println("Invalid input. Please enter a valid price.");
                            input.next(); 
                        }
                        newPrice = input.nextDouble();
                        input.nextLine(); 
                    } while (newPrice < 0); // Ensure price is non-negative
                    selectedPainting.setPrice(newPrice);
                    System.out.println("Price updated successfully.");
                    break;
                case 3:
                    System.out.println("Enter the new printed status:\n1. Yes\n2. No");
                    String newPrinted;
                    do {
                        newPrinted = input.nextLine();
                    } while (!isValidYesNo(newPrinted));

                    newPrinted = newPrinted.equals("1") ? "Yes" : "No";

                    selectedPainting.setPrinted(newPrinted);
                    System.out.println("Printed status updated successfully.");
                    break;
                case 4:
                    System.out.println("Enter the new Type of Paint (Oil, Acrylic, Watercolor): ");
                    String newPaintType;
                    do {
                        newPaintType = input.nextLine();
                    } while (!isValidPaintType(newPaintType));

                    selectedPainting.setPaintType(newPaintType);
                    System.out.println("Paint type updated successfully.");
                    break;
                case 5:
                    System.out.println("Enter the new size (in the format numberxnumber): ");
                    String newSize;
                    do {
                        newSize = input.nextLine();
                    } while (!isValidSize(newSize));
                    selectedPainting.setSize(newSize);
                    System.out.println("Size updated successfully.");
                    break;

                case 0:
                    System.out.println("Exiting update process.");
                    break;
                default:
                    System.out.println("Invalid choice. Please choose 1, 2, 3, 4, 5, 6, or 0.");
                    break;
            }
        } while (updateChoice != 0);
    } else {
        System.out.println("Painting with Service ID " + paintingIdToUpdate + " not found.");
    }
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
// validate if a string is in the format "numberxnumber"
private boolean isValidSize(String input) {
    return input.matches("\\d{1,3}x\\d{1,3}");
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
// validate painting service ID
private boolean isValidPaintingId(String input, ArrayList<Paintings> paintings) {
    if (input.length() == 3 && isInteger(input)) {
        int paintingId = Integer.parseInt(input);

        if (paintingId >= 0 && paintingId < 100) {
            // Check if the ID already exists in the paintings ArrayList
            for (Paintings painting : paintings) {
                if (painting.serviceId.equals(input)) {
                    return true; // ID exists
                }
            }
        }
    }
    return false;
}
// ---------------------------------------------------------------------------------------------------------------------------------------------------------
    // updating event method that is used in the updateServiceMenu method
public void updateEvent(ArrayList<Event> events) {
    Scanner input = new Scanner(System.in);
    String eventIdToUpdate;

    // Get a valid event ID from the user
    while (true) {
        System.out.println("Enter the service ID of the event you want to update (Enter '0' to cancel): ");
        eventIdToUpdate = input.nextLine();
        if (eventIdToUpdate.equals("0")) {
            System.out.println("Update process canceled.");
            return;
        }
        if (isValidEventId(eventIdToUpdate, events)) {
            break;
        }
        System.out.println("Invalid input. Please enter a valid service ID for events.");
    }

    // Find the event with the given service ID
    Event selectedEvent = null;
    for (Event event : events) {
        if (event.serviceId.equals(eventIdToUpdate)) {
            selectedEvent = event;
            break;
        }
    }

    // Check if the event was found
    if (selectedEvent != null) {
        // Display the current information of the selected event
        System.out.println("Current Information for " + selectedEvent.serviceId);
        System.out.println("1. Name: " + selectedEvent.getName());
        System.out.println("2. Price: " + selectedEvent.getPrice() + "SR");
        System.out.println("3. Free: " + selectedEvent.getFree());
        System.out.println("4. Online: " + selectedEvent.getOnline());
        System.out.println("5. Date: " + selectedEvent.getDate());
        System.out.println("0. Exit");

        // Get the update choice from the user
        int updateChoice;
        do {
            System.out.println("Choose the information to update (1, 2, 3, 4, 5, or 0 to exit): ");
            while (!input.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                input.next(); 
            }
            updateChoice = input.nextInt();
            input.nextLine(); 

            switch (updateChoice) {
                case 1:
                    System.out.println("Enter the new name: ");
                    String newName;
                    do {
                        newName = input.nextLine();
                    } while (!isValidWordsWithSpaces(newName));
                    selectedEvent.setName(newName);
                    System.out.println("Name updated successfully.");
                    break;

                case 2:
                    System.out.println("Enter the new price: ");
                    double newPrice;
                    do {
                        while (!input.hasNextDouble()) {
                            System.out.println("Invalid input. Please enter a valid price.");
                            input.next(); 
                        }
                        newPrice = input.nextDouble();
                        input.nextLine(); 
                    } while (newPrice < 0); // Ensure price is non-negative
                    selectedEvent.setPrice(newPrice);
                    System.out.println("Price updated successfully.");
                    break;
                case 3:
                    System.out.println("Enter the new free status (Yes/No): ");
                    String newFree;
                    do {
                        newFree = input.nextLine();
                    } while (!isValidYesNo(newFree));
                    selectedEvent.setFree(newFree);
                    System.out.println("Free status updated successfully.");
                    break;
                case 4:
                    System.out.println("Enter the new online status (Yes/No): ");
                    String newOnline;
                    do {
                        newOnline = input.nextLine();
                    } while (!isValidYesNo(newOnline));
                    selectedEvent.setOnline(newOnline);
                    System.out.println("Online status updated successfully.");
                    break;
                case 5:
                    System.out.println("Enter the new date: ");
                    String newDate;
                    do {
                        newDate = input.nextLine();
                    } while (!isValidString(newDate));
                    selectedEvent.setDate(newDate);
                    System.out.println("Date updated successfully.");
                    break;
                case 0:
                    System.out.println("Exiting update process.");
                    break;
                default:
                    System.out.println("Invalid choice. Please choose 1, 2, 3, 4, 5, 6, or 0.");
                    break;
            }

        } while (updateChoice != 0);
    } else {
        System.out.println("Event with Service ID " + eventIdToUpdate + " not found.");
    }
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------
// validate event service ID
private boolean isValidEventId(String input, ArrayList<Event> events) {
    if (input.length() == 3 && isInteger(input)) {
        int eventId = Integer.parseInt(input);

        if (eventId > 100 && eventId < 200) {
            // Check if the ID already exists in the events ArrayList
            for (Event event : events) {
                if (event.serviceId.equals(input)) {
                    return true; // ID exists
                }
            }
        }
    }
    return false;
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------            
//------------------------------------------------------------------------------//------------------------------------------------------------------------------    
    // deleting supplies method that is used in the deleteServiceMenu method
public void deleteSupplies(ArrayList<Supplies> supplies) {
    Scanner input = new Scanner(System.in);
    
    System.out.println("Enter the service ID of the Supply you want to delete (Enter '0' to cancel): ");
    String supplyIdToDelete = input.nextLine();

    // Check if the user wants to cancel the deletion
    if (supplyIdToDelete.equals("0")) {
        System.out.println("Deletion process canceled.");
        return;
    }

    // Find the supply with the given service ID
    Supplies selectedSupply = null;
    for (Supplies supply : supplies) {
        if (supply.serviceId.equals(supplyIdToDelete)) {
            selectedSupply = supply;
            break;
        }
    }

    // Check if the supply was found
    if (selectedSupply != null) {
        supplies.remove(selectedSupply);
        System.out.println("Supply deleted successfully!");
    } else {
        System.out.println("Supply with Service ID " + supplyIdToDelete + " not found.");
    }
}
//------------------------------------------------------------------------------//------------------------------------------------------------------------------         
    // deleting painting method that is used in the deleteServiceMenu method
public void deletePainting(ArrayList<Paintings> paintings) {
    Scanner input = new Scanner(System.in);
    
    System.out.println("Enter the service ID of the painting you want to delete (Enter '0' to cancel): ");
    String paintingIdToDelete = input.nextLine();

    // Check if the user wants to cancel the deletion
    if (paintingIdToDelete.equals("0")) {
        System.out.println("Deletion process canceled.");
        return;
    }

    // Find the painting with the given service ID
    Paintings selectedPainting = null;
    for (Paintings painting : paintings) {
        if (painting.serviceId.equals(paintingIdToDelete)) {
            selectedPainting = painting;
            break;
        }
    }

    // Check if the painting was found
    if (selectedPainting != null) {
        paintings.remove(selectedPainting);
        System.out.println("Painting deleted successfully!");
    } else {
        System.out.println("Painting with Service ID " + paintingIdToDelete + " not found.");
    }
}

// ---------------------------------------------------------------------------------------------------------------------------------------------------------
   // deleting event method that is used in the deleteServiceMenu method
public void deleteEvent(ArrayList<Event> events) {
    Scanner input = new Scanner(System.in);

    System.out.println("Enter the service ID of the event you want to delete (Enter '0' to cancel): ");
    String eventIdToDelete = input.nextLine();

    // Check if the user wants to cancel the deletion
    if (eventIdToDelete.equals("0")) {
        System.out.println("Deletion process canceled.");
        return;
    }

    // Find the event with the given service ID
    Event selectedEvent = null;
    for (Event event : events) {
        if (event.serviceId.equals(eventIdToDelete)) {
            selectedEvent = event;
            break;
        }
    }

    // Check if the event was found
    if (selectedEvent != null) {
        events.remove(selectedEvent);
        System.out.println("Event deleted successfully!");
    } else {
        System.out.println("Event with Service ID " + eventIdToDelete + " not found.");
    }
}

//---------------------------------------------------------------------------------------------------------------------------------------------------------    
} // end of Employee class*/

}





