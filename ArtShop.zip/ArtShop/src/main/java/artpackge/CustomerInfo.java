 
package artpackge;

import java.util.*;

public class CustomerInfo{
    HashMap<String,String > customHashMap=new HashMap<String,String>();
    private String uString,pString;

    public CustomerInfo() {
        customHashMap.put("Sara", "pass");
        customHashMap.put("Dana", "gass");
        customHashMap.put("lara", "tass");


    }
    public void addKeyValue(String userString,String passwordString){
        uString=userString;
        pString=passwordString;
        customHashMap.put(uString, uString);
    }

    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone(); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/OverriddenMethodBody
    }

    boolean containsKey(String em) {
        return customHashMap.containsKey(em);
    }

    boolean get(String em,String pa) {
        return customHashMap.get(em).equals(pa);
    }
    
    
}
