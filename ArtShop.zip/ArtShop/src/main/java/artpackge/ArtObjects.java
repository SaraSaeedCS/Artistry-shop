/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package artpackge;
import ShopObjects.*;
import ShopObjects.Art_Shop;

/**
 *
 * @author fatim
 */
public class ArtObjects {
    static Art_Shop artObjects= new Art_Shop();
}
