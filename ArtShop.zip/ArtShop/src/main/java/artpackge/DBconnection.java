/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package artpackge;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
public class DBconnection {
    
   
   
   
    public static void main(String[] args) {
        
        Connection con;
        PreparedStatement pst;
         try {
           Class.forName("com.mysql.cj.jdbc.Driver");
           con=DriverManager.getConnection("jdbc:mysql://localhost:3306/art","root","root");
           System.out.print("succses");
       } catch (ClassNotFoundException e) {
             Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE,null,e);
       }catch(SQLException e){
            Logger.getLogger(DBconnection.class.getName()).log(Level.SEVERE,null,e);
       }
    }
}
