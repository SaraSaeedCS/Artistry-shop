

package artpackge;

import javax.swing.JFrame;

import ShopObjects.*;
import java.awt.Image;
import java.awt.Toolkit;


public class ArtShop {
    


    public static void main(String[] args) {
      HomePageD f=new HomePageD();
      f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      Image icon = Toolkit.getDefaultToolkit().getImage("C:\\Users\\Olive\\Pictures");  
      f.setIconImage(icon);
      f.setResizable(false);
      f.setVisible(true);
      
      
     
      
    }
}
